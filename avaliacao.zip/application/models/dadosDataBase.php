<?php

defined('BASEPATH') OR exit('No direct script access allowed');
	
class DadosDataBase extends CI_Model {

	public $servidor = "";
	public $usuario = "";
	public $senha = "";
	public $dataBase = "";

}