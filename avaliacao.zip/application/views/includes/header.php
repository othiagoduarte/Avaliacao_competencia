<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
<title><?php echo isset($title) ? $title : 'Bem vindo'; ?></title>
<!-- JS  -->
<script type="text/javascript" src="<?php echo base_url('js/jquery.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/init.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/materialize.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/usuarios.js')?>"></script>
<!-- CSS  -->
<link href="<?php echo base_url('css/materialize.css')?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('css/style.css')?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('css/Sobre.css')?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('css/Sobre.css')?>" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">