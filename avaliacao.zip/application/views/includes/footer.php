<footer class="page-footer black pull-left">
  <div class="container">
    <div class="row texto-footer ">
      <p>Desenvolvido por Thiago Duate</p>
    </div>
</footer>