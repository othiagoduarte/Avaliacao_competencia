<div class="row s12">
	<div class="row">
    	<br>
    	<div class="center">
    		<b>  <?php echo isset($mensagem)?$mensagem:"Dados do usuário"; ?> <b>
    	</div>
		<?php include "detalhe.php"?>	
	</div>		
</div>		